# ar-chitect - report

## Custom

### Bug~Other

```
 - nothing recorded yet, the application has not been run
```

### Design

```
 - nothing recorded yet, the application has not been run
```

## Test Plan (can be inacurate on some of them)

> [!IMPORTANT]
> Anything that require external file was not tested!!!

### F-01 - Create a client account
> 🟢 **OK**

### F-02 - Create a company account
> 🟢 **OK**

### F-03 - Log in as a client
> 🟢 **OK**

### F-04 - Log in as a company
> 🟢 **OK**

### F-05 - Delete an account
> 🟢 **OK**

### F-06 - Reset a password
> 🟢 **OK**

### F-07 - Log out
> 🟢 **OK**

### F-08 - Navigate to the catalogue
> 🟢 **OK**

### F-09 - Navigate to the Scan page
> 🟢 **OK**

### F-10 - Browse the catalogue
> 🟢 **OK**

### F-11 - Refresh the catalogue
> 🟢 **OK**

### F-12 - Refresh the scans
> 🟢 **OK**

### F-13 - View catalogue furniture details
> 🟢 **OK**

### F-14 - View scan furniture details
> 🟢 **OK**

### F-15 - Search catalogue furniture
> 🟢 **OK**

### F-16 - Search scan furniture
> 🟢 **OK**

### F-17 - Filter furniture by type
> 🟢 **OK**

### F-18 - Launch AR visualisation
> 🟢 **OK**

### F-19 - Move furniture in AR
> 🟢 **OK**

### F-20 - Rotate furniture in AR
> 🟢 **OK**

### F-21 - Import a 3D model
> 🟢 **OK**

### F-22 - Place a 3D model in AR
> 🟢 **OK**

### F-23 - View imported 3D models
> 🟢 **OK**

### F-24 - Rename an imported model
> 🟢 **OK**

### F-25 - Delete an imported model
> 🔴 **NONE**

### F-26 - View a company or client profile
> 🟢 **OK**

### F-27 - Edit a company or client profile
> 🟢 **OK**

### F-28 - Submit a furniture item
> 🟢 **OK**

### F-29 - Hide a furniture item
> 🟢 **OK**

### F-30 - Add credits
> 🔴 **NONE**

### F-31 - Pay subscription
> 🔴 **NONE**

### F-32 - Cancel subscription
> 🔴 **NONE**

### F-33 - Scan a furniture
> 🔴 **NONE**

### F-34 - Use credits
> 🔴 **NONE**

### F-35 - Access admin account
> 🟢 **OK**

### F-36 - View furniture details on admin history page
> 🟢 **OK**

### F-37 - View furniture details on admin in review page
> 🟢 **OK**

### F-38 - View 3D model as admin validating a submission
> 🔴 **NONE**

### F-39 - Approve a furniture submission
> 🟢 **OK**

### F-40 - Reject a furniture submission
> 🟢 **OK**

### F-41 - Scale an imported 3D model
> 🔴 **NONE**

### F-42 - Send a help request
> 🔴 **NONE**
